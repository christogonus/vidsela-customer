
<x-layouts.app>
    <livewire:webinar :video="$video" />
</x-layouts.app>
