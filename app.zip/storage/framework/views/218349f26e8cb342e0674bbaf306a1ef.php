<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title' => null,]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title' => null,]); ?>
<?php foreach (array_filter((['title' => null,]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo e($title ?? config('app.name')); ?></title>

    

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link rel="preconnect" href="https://fonts.googleapis.com"/>

    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


    <link rel="stylesheet" href="https://cdn.plyr.io/3.7.8/plyr.css" />

    <style> .plyr iframe[id^=youtube] { top: -50%; height: 200%;}iframe {pointer-events: none;} </style>

    <?php echo $__env->yieldPushContent('styles'); ?>

</head>
<body class="h-full  flex flex-col">

 <?php echo e($slot); ?>


 <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

 <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\visela-customer\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>