<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo e(config('app.name')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link rel="preconnect" href="https://fonts.googleapis.com"/>

    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <link rel="stylesheet" href="https://cdn.plyr.io/3.7.8/plyr.css" />

    <style>
        .plyr iframe[id^=youtube] { top: -50%; height: 200%;}iframe {pointer-events: none;}
    </style>

</head>
<body class="h-full  flex flex-col">

<div class="w-full">

    <div class="w-full flex justify-center h-full px-[2rem] bg-black py-[2rem]">
        <div>
            <div class="my-3 text-center">
                <h1 class="fontRusso text-[60px] text-[#FDB600]">Just buy it NOW!</h1>
                <h1 class="fontRusso text-[60px] text-white">Lorem Ipsum Lorem IpsumLorem Ipsum</h1>
            </div>

            <div class="w-full">
                <div class="w-full sm:w-2/3 m-auto">
                    <div class="relative border-2 border-gray-400 rounded-md shadow-md overflow-hidden">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.plyr','data' => ['link' => 'https://www.youtube.com/watch?v=iNv1uVoDEgs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('plyr'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['link' => 'https://www.youtube.com/watch?v=iNv1uVoDEgs']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="my-8 fontOut flex flex-col space-y-7 items-center">
                <button class="text-[36px] font-[800] back rounded-md px-5 py-5 text-white">
                    <a href="#public/buy-it-claim1.html">Click here to access now</a>
                </button>
                <div class="px-3 py-4 border-4 border-[#FDB600] text-white fontRusso text-[36px]">Forem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero</div>
            </div>
        </div>

    </div>

</div>


<script src="https://cdn.plyr.io/3.7.8/plyr.polyfilled.js"></script>
<script>
    const player = new Plyr('#presenter');
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\visela-customer\resources\views/components/layouts/vsl.blade.php ENDPATH**/ ?>