<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['link' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['link' => '']); ?>
<?php foreach (array_filter((['link' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $getSource = parse_url($link);

    if($link == '' || ! isset($getSource['host'])) {
        $getSource = parse_url(config("video.blank"));
    }

    if (str_contains($getSource['host'], 'youtube.com') || str_contains($getSource['host'], "youtu.be")){
        $source = "youtube";
    }else if (str_contains($getSource['host'], 'vimeo.com')){
        $source = "vimeo";
    }else {
        $source = 'custom';
    }

?>

<?php if($source == 'youtube' || $source == 'vimeo'): ?>

    
    <div id="presenter" class="absolute aspect-video "
         data-plyr-provider="<?php echo e($source); ?>"
         data-plyr-embed-id="<?php echo e($link); ?>"
    ></div>

<?php else: ?>

    
    <video id="presenter"
           class="absolute aspect-video "
           playsinline controls
    >
        <source src="<?php echo e($link); ?>" type="video/mp4" />
    </video>

<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\visela-customer\resources\views/components/plyr.blade.php ENDPATH**/ ?>