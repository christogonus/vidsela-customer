
# Vidsela Front End 

The pages for the videos and webinars
