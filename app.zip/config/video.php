<?php

return [
    'blank' => env('NO_VIDEO'),

];
